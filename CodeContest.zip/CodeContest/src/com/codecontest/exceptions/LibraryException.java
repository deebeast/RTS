package com.codecontest.exceptions;

public class LibraryException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4079428634004855980L;

	public LibraryException(String message) {
		super(message);
	}

	public LibraryException(Throwable cause) {
		super(cause);
	}

	public LibraryException(String message, Throwable cause) {
		super(message, cause);
	}

}
