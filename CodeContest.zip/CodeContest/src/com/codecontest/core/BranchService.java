package com.codecontest.core;

import java.util.ArrayList;

import com.codecontest.beans.Branch;
import com.codecontest.exceptions.LibraryException;

public interface BranchService {
	ArrayList<Branch> getBranchList() throws LibraryException;

	Branch getBranchOnId(long id) throws LibraryException;

	void deleteBranchById(Branch b) throws LibraryException;

	void addBranch(Branch b) throws LibraryException;
}
