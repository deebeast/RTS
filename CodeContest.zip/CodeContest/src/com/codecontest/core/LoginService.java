package com.codecontest.core;

import com.codecontest.beans.Login;

public interface LoginService {

	Boolean checkLogin(Login l);
}
