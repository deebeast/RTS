package com.codecontest.core;

import com.codecontest.beans.Login;
import com.codecontest.daos.LoginDao;
import com.codecontest.daos.LoginDaoImpl;

public class LoginServiceImpl implements LoginService {
	private LoginDao dao;
	
	public LoginServiceImpl() {
		dao = new LoginDaoImpl();
	}
	@Override
	public Boolean checkLogin(Login l) {
		return dao.checkLogin(l);
	}

}
