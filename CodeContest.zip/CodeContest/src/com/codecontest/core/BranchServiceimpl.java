package com.codecontest.core;

import java.util.ArrayList;

import com.codecontest.beans.Branch;
import com.codecontest.daos.BranchDao;
import com.codecontest.daos.BranchDaoImpl;
import com.codecontest.exceptions.LibraryException;

public class BranchServiceimpl implements BranchService {
	private BranchDao dao;

	public BranchServiceimpl() {
		dao = new BranchDaoImpl();
	}

	@Override
	public ArrayList<Branch> getBranchList() throws LibraryException {
		return dao.getBranchList();
	}

	@Override
	public Branch getBranchOnId(long id) throws LibraryException {
		return dao.getBranchOnId(id);
	}

	@Override
	public void deleteBranchById(Branch b) {
		dao.deleteBranchById(b);
	}

	@Override
	public void addBranch(Branch b) throws LibraryException {
		dao.addBranch(b);
	}

}
