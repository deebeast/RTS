package com.codecontest.tests;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.codecontest.beans.Branch;

public class TestBranch {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("CodeContest");
		EntityManager em = emf.createEntityManager();
		Query q = em.createNamedQuery("Branch.findAll");
		ArrayList<Branch> allBranch = new ArrayList<Branch>(q.getResultList());
		
		for (Branch b : allBranch) {
			System.out.println(b);
		}
	}

}
