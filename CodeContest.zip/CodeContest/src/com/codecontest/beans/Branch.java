package com.codecontest.beans;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the BRANCH database table.
 * 
 */
@Entity
@Table(name="BRANCH")
@NamedQuery(name="Branch.findAll", query="SELECT b FROM Branch b")
public class Branch implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="BRANCH_ID", unique=true, nullable=false, precision=10)
	private long branchId;

	@Column(name="BRANCH_ADDRESS", nullable=false, length=200)
	private String branchAddress;

	@Column(name="BRANCH_NAME", nullable=false, length=50)
	private String branchName;

	@Column(name="PHONE_NO", nullable=false, length=20)
	private String phoneNo;

	public Branch() {
	}

	public long getBranchId() {
		return this.branchId;
	}

	public void setBranchId(long branchId) {
		this.branchId = branchId;
	}

	public String getBranchAddress() {
		return this.branchAddress;
	}

	public void setBranchAddress(String branchAddress) {
		this.branchAddress = branchAddress;
	}

	public String getBranchName() {
		return this.branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getPhoneNo() {
		return this.phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Branch [branchId=" + branchId + ", branchAddress=" + branchAddress + ", branchName=" + branchName
				+ ", phoneNo=" + phoneNo + "]";
	}
	
}