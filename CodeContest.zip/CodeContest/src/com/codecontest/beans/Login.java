package com.codecontest.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbllogin")
public class Login {
	@Id
	@Column(name = "USER_ID")
	int userId;

	@Column(name = "USER_ROLE")
	String userRole;

	@Column(name = "LOGIN_PASSWORD")
	String loginPassword;

	public Login() {
		super();
	}

	public Login(int userId, String userRole, String loginPassword) {
		super();
		this.userId = userId;
		this.userRole = userRole;
		this.loginPassword = loginPassword;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
}
