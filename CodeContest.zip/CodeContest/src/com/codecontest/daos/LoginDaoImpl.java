package com.codecontest.daos;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.codecontest.beans.Login;

public class LoginDaoImpl implements LoginDao {
	private EntityManagerFactory emf;
	private EntityManager em;

	public LoginDaoImpl() {
		emf = Persistence.createEntityManagerFactory("CodeContest");
		em = emf.createEntityManager();
	}

	@Override
	public Boolean checkLogin(Login l) {
		Login newL = em.find(Login.class, l.getUserId());
		if (newL != null) {
			if (l.getLoginPassword().equals(newL.getLoginPassword())) {
				return true;
			}
		}
		return false;
	}

}
