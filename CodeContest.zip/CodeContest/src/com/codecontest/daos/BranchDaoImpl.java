package com.codecontest.daos;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.codecontest.beans.Branch;
import com.codecontest.exceptions.LibraryException;

public class BranchDaoImpl implements BranchDao {

	private EntityManagerFactory emf;
	private EntityManager em;

	public BranchDaoImpl() {
		emf = Persistence.createEntityManagerFactory("CodeContest");
		em = emf.createEntityManager();
	}

	@Override
	public ArrayList<Branch> getBranchList() throws LibraryException {
		Query q = em.createNamedQuery("Branch.findAll");
		ArrayList<Branch> allBranch = new ArrayList<Branch>(q.getResultList());
		return allBranch;
	}

	@Override
	public Branch getBranchOnId(long id) {
		Branch b = em.find(Branch.class, id);
		return b;
	}

	@Override
	public void deleteBranchById(Branch b) {
		em.getTransaction().begin();
		Branch br = em.find(Branch.class, b.getBranchId());
		em.remove(br);
		em.getTransaction().commit();
	}

	@Override
	public void addBranch(Branch b) {
		em.getTransaction().begin();
		em.persist(b);
		em.getTransaction().commit();
	}

}
