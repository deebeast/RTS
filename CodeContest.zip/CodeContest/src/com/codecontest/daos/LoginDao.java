package com.codecontest.daos;

import com.codecontest.beans.Login;

public interface LoginDao {

	Boolean checkLogin(Login l);
}
