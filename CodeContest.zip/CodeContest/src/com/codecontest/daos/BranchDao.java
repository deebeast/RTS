package com.codecontest.daos;

import java.util.ArrayList;
import com.codecontest.beans.Branch;
import com.codecontest.exceptions.LibraryException;

public interface BranchDao {
	ArrayList<Branch> getBranchList() throws LibraryException;

	Branch getBranchOnId(long id);

	void deleteBranchById(Branch b);

	void addBranch(Branch b);
}
