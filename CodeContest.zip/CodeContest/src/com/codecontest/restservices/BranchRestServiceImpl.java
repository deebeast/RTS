package com.codecontest.restservices;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.codecontest.beans.Branch;
import com.codecontest.core.BranchService;
import com.codecontest.core.BranchServiceimpl;
import com.codecontest.exceptions.LibraryException;

//URL : http://localhost:8081/CodeContest/rest/branch/branchlist
//URL : http://localhost:8081/CodeContest/rest/branch/branchdelete/1

@Path("/branch")
public class BranchRestServiceImpl {
	private BranchService service;

	public BranchRestServiceImpl() {
		service = new BranchServiceimpl();
	}

	//
	@GET
	@Path("/branchlist")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Branch> getBranchList() throws LibraryException {
		return service.getBranchList();
	}

	@GET
	@Path("/branchDetails/{branchId}") //
	@Produces(MediaType.APPLICATION_JSON)
	public Branch getBranchDetails(@PathParam("branchId") long id) throws LibraryException {
		return service.getBranchOnId(id);
	}

	@DELETE
	@Path("/branchdelete/{branchId}")
	public void deleteBranch(@PathParam("branchId") long id) throws LibraryException {
		Branch b = new Branch();
		b.setBranchId(id);
		service.deleteBranchById(b);
	}

	@GET
	@Path("/verify")
	@Produces(MediaType.TEXT_PLAIN)
	public Response verifyRestService(InputStream incomingData) {
		String result = "RESTService Successfully started..";
		// return HTTP response 200 in case of success
		return Response.status(200).entity(result).build();
	}

	@POST
	@Path("/branchAdd")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response branchAdd(Branch b) throws LibraryException {
		service.addBranch(b);
		return Response.status(201).entity(b).build();
	}

}